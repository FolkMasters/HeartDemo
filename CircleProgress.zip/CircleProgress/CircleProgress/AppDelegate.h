//
//  AppDelegate.h
//  CircleProgress
//
//  Created by LSQ on 2017/8/15.
//  Copyright © 2018年 lishiqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

