//
//  ViewController.m
//  CircleProgress
//
//  Created by LSQ on 2017/8/15.
//  Copyright © 2018年 lishiqian. All rights reserved.
//

#import "ViewController.h"
#import "FKCircleView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGFloat width =self.view.frame.size.width;
    FKCircleView *circleView =[[FKCircleView alloc]initWithFrame:CGRectMake(0, 0, width, width)];
    circleView.center = self.view.center;
    [self.view addSubview:circleView];
    [circleView startDrawCircle:0.6];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
