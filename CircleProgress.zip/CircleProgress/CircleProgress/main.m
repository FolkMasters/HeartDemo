//
//  main.m
//  CircleProgress
//
//  Created by LSQ on 2017/8/15.
//  Copyright © 2018年 lishiqian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
