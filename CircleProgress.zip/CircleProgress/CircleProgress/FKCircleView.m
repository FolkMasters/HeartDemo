//
//  FKCircleView.m
//  test
//
//  Created by LSQ on 2017/8/15.
//  Copyright © 2017年 lishiqian. All rights reserved.
//

#import "FKCircleView.h"

#define SelfWidth self.frame.size.width
#define SelfHeight self.frame.size.height

@interface FKCircleView ()
@property (nonatomic,strong) UILabel *textLabel;
@end

@implementation FKCircleView

-(instancetype)initWithFrame:(CGRect)frame{
    self =[super initWithFrame:frame];
    if (self){
        // 初始化参数
        self.radius = 130.0f;
        self.normalCircleColor = [UIColor grayColor];
        self.animalCircleColor =[UIColor redColor];
        self.circleLineWidth = 5.0;
        self.duration = 3.0;        
    }
    return self;
}

/**
 绘制默认圆
 */
-(CAShapeLayer*)normalCircle{
    CAShapeLayer *normalCircle =  [CAShapeLayer layer];
    normalCircle.lineWidth = self.circleLineWidth;
    normalCircle.strokeColor = self.normalCircleColor.CGColor;
    normalCircle.fillColor = [UIColor clearColor].CGColor;
    //设置中心点以及frame
    CGRect rect = CGRectMake((SelfWidth - self.radius*2)/2, (SelfHeight - self.radius*2)/2, self.radius*2, self.radius*2);
    CGMutablePathRef circlePath =  CGPathCreateMutable();
    CGPathAddEllipseInRect(circlePath, nil, rect);
    
    normalCircle.path = circlePath;
    CGPathRelease(circlePath);
    
    
    return normalCircle;
}

/**
 绘制 动画圆 路径

 @param value 百分比值
 */
-(CAShapeLayer *)animationCircleValue:(CGFloat)value{
    CAShapeLayer *animationCircle =[CAShapeLayer new];
    animationCircle.lineWidth = self.circleLineWidth;
    //圆环的颜色
    animationCircle.strokeColor = self.animalCircleColor.CGColor;
    //背景填充色
    animationCircle.fillColor = [UIColor clearColor].CGColor;
    //指定线的边缘是圆的
    animationCircle.lineCap = kCALineCapRound;
    //按照顺时针方向
    BOOL clockWise = true;
    
    CGPoint center = CGPointMake(CGRectGetWidth(self.bounds)/2.0, CGRectGetHeight(self.bounds)/2.0);
    CGFloat endAngle =1.5*M_PI + value * M_PI * 2;
    //初始化一个路径
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:self.radius startAngle:1.5*M_PI endAngle:endAngle clockwise:clockWise];
    animationCircle.path = [path CGPath];
    return animationCircle;
}


/**
 set textLabel
 */
-(UILabel *)textLabel{
    if (!_textLabel) {
        _textLabel =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
        _textLabel.backgroundColor =[UIColor redColor];
        _textLabel.textColor =[UIColor blackColor];
        _textLabel.text = @"100%";
        _textLabel.font =[UIFont systemFontOfSize:10.0f];
        _textLabel.layer.cornerRadius = 15;
        _textLabel.layer.masksToBounds = YES;
        _textLabel.textAlignment = NSTextAlignmentCenter;
        _textLabel.center = CGPointMake((SelfWidth - self.radius*2)/2, (SelfHeight - self.radius*2)/2);
        _textLabel.alpha =0;
    }
    return _textLabel;
}


-(void)startDrawCircle:(CGFloat)value{
    for (CALayer *layer in self.layer.sublayers) {
        [layer removeFromSuperlayer];
    }
    //添加默认圆
    [self.layer addSublayer:[self normalCircle]];
    
    CAShapeLayer *layer = [self animationCircleValue:value];
    [self.layer addSublayer:layer];
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.duration = self.duration;
    animation.fromValue=[NSNumber numberWithInteger:0];
    animation.toValue=[NSNumber numberWithInteger:1];
    [layer addAnimation:animation forKey:@"key"];
    
    
    [self addSubview:self.textLabel];
    self.textLabel.alpha = 1;
    self.textLabel.text = [NSString stringWithFormat:@"%.f%%",value*100];
    //创建运转动画
    CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    pathAnimation.calculationMode = kCAAnimationPaced;
    pathAnimation.fillMode = kCAFillModeForwards;
    pathAnimation.removedOnCompletion = NO;
    pathAnimation.duration = self.duration;
    //设置运转动画的路径
    CGMutablePathRef curvedPath = CGPathCreateMutable();
    CGFloat endAngle =1.5*M_PI + value * M_PI * 2;
    CGPathAddArc(curvedPath, NULL, CGRectGetWidth(self.bounds) / 2, CGRectGetHeight(self.bounds) /2, self.radius, 1.5*M_PI, endAngle, 0);
    pathAnimation.path = curvedPath;
    CGPathRelease(curvedPath);
    [self.textLabel.layer addAnimation:pathAnimation forKey:@"animation"];
    
}

@end
