//
//  FKCircleView.h
//  test
//
//  Created by LSQ on 2017/8/15.
//  Copyright © 2017年 lishiqian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKCircleView : UIView

/**
 半径
 */
@property (nonatomic,assign)CGFloat radius;

/**
 底图圆颜色
 */
@property (nonatomic,strong) UIColor *normalCircleColor;

/**
 动画圆颜色
 */
@property (nonatomic,strong) UIColor *animalCircleColor;

/**
 圆线条宽度
 */
@property (nonatomic,assign)CGFloat circleLineWidth;

/**
 一圈动画时长
 */
@property(nonatomic,assign)CGFloat duration;


/**
 开始绘制动画

 @param value 百分比
 */
-(void)startDrawCircle:(CGFloat)value;

@end
